﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("GOLDEN MARKIPLIER")


# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bg room
    play music "audio/music.mp3" volume 0.15


    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    show golden at left

    # These display lines of dialogue.

    play sound "audio/talk.mp3" volume 0.25
    "???" "Hello."

    play sound "audio/talk.mp3" volume 0.25
    "???" "I am GOLDEN MARKIPLIER."
    

    play sound "audio/talk.mp3" volume 0.25
    e "What are you doing in Dexo's room? How did you get here?"

    play sound "audio/talk.mp3" volume 0.25
    e "I am his room guardian. I guard him as he sleeps."
    
    play sound "audio/talk.mp3" volume 0.25
    e "You appear to be some kind of burgaling felon. You don't belo-"

    play sound "audio/talk.mp3" volume 0.25
    e "Wait."

    play sound "audio/talk.mp3" volume 0.25
    e "Burgaling?"

    play sound "audio/talk.mp3" volume 0.25
    e "Burgling?"

    play sound "audio/talk.mp3" volume 0.25
    e "Burgerling?"

    play sound "audio/talk.mp3" volume 0.25
    e "You're a burglar is what I'm saying."

    play sound "audio/talk.mp3" volume 0.25
    e "Prepare to die."

    # This ends the game.

    return
